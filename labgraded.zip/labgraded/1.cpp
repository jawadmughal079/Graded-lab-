#include <iostream>
using namespace std;
void menu();
void valueShow(int *ptr, int size);
int searchingFuction(int num, int size, int *ptr);
void valueShiffter(int *ptrArr1, int size, int returnSaver);

int main()
{
    int choice = 0;
    int size = 0;
    int searchNum = 0;
    int returnSaver = 0;
    cout << " Enter a size of Array";
    cout << endl;
    cin >> size;

    int *ptrArr1 = new int[size];
    for (int i = 0; i < size; i++)
    {
        cout << "Enter " << i + 1 << " Value : ";
        cin >> *(ptrArr1 + i);
    }
    cout << " \nThose Values You Entered \n";
    valueShow(ptrArr1, size);
    cout
        << "\n------------------------------NOW SHRINK PROCESS IS START--------------------------------\n";
    cout << endl;
    while (true)
    {
        menu();
        cout << " Choice : ";
        cin >> choice;
        if (choice == -1)
        {
            cout << "\n YOUR SHRINK PROCESS IS OVER \n";
            cout << endl;
            break;
        }
        else
        {
            cout << endl;
            cout << " Enter a num You Want To search  : ";
            cin >> searchNum;

            returnSaver = searchingFuction(searchNum, size, ptrArr1);
            cout << endl;
            if (returnSaver == -1)
            {
                cout << " Your Value Is Not Present \n";
                cout << endl;
            }
            else
            {
                valueShiffter(ptrArr1, size, returnSaver);
                size -= 1;
                cout << " Succesfully Your Number Is Deleted ";
                cout << endl;
                cout << " Now Your size is " << size;
                cout << endl;
                cout << " \nThose Values are Left\n";
                valueShow(ptrArr1, size);
            }
            cout << endl;
            if (size == 0)
            {
                cout << "\n YOUR SHRINK PROCESS IS OVER BECAUSE SIZE IS EQUAL TO ZERO\n";
                cout << endl;
                break;
            }
        }
    }
    delete[] ptrArr1;
    return 0;
}
void menu()
{
    cout << " Press 6 for Exit from program ";
    cout << endl;
    cout << " Press any key for continue The Program ";
    cout << endl;
}
int searchingFuction(int num, int size, int *ptr)
{
    for (int i = 0; i < size; i++)
    {
        if (num == *(ptr + i))
        {
            return i;
            break;
        }
    }
    return -1;
}
void valueShow(int *ptr, int size)
{

    for (int i = 0; i < size; i++)
    {
        cout << i + 1 << " Value : ";
        cout << *(ptr + i);
        cout << endl;
    }
}
void valueShiffter(int *ptrArr1, int size, int returnSaver)
{

    for (int i = returnSaver; i <= size; i++)
    {
        *(ptrArr1 + i) = *(ptrArr1 + i + 1);
    }
}