#include <iostream>
using namespace std;
void enterValue(int *ptrArr1, int size, int &total);
void valueShow(int *ptr, int total);
void copyData(int *ptrArr1, int *temp, int total);
void insertData(int *ptr, int &total, int searchNum);
void menu();
int main()
{
    int total = 0;
    int searchNum = 0;
    int choice = 0;
    int size = 0;
    cout << " ENTER A SIZE OF ARRAY : ";
    cin >> size;
    int *ptrArr1 = new int[size];
    cout << "\n Enter The Value \n";
    enterValue(ptrArr1, size, total);
    cout << endl;
    cout << " \nThose Values You Entered \n";
    valueShow(ptrArr1, total);
    cout
        << "\n------------------------------NOW REGROW PROCESS IS START--------------------------------\n";
    cout << endl;
    while (true)
    {
        menu();
        cout << " Choice : ";
        cin >> choice;
        if (choice == -1)
        {
            cout << "\n YOUR REGROW PROCESS IS OVER \n";
            cout << endl;
            break;
        }
        else
        {
            cout << endl;
            cout << " Enter a num You Want To Add  : ";
            cin >> searchNum;

            if (total < size)
            {
                insertData(ptrArr1, total, searchNum);
            }

            if (total >= size)
            {
                size = size * 2;
                int *temp = new int[size];
                copyData(ptrArr1, temp, total);
                delete[] ptrArr1;
                ptrArr1 = temp;
                insertData(ptrArr1, total, searchNum);
            }
            cout << endl;
            cout << " REGROW SIZE IS : " << size;
            cout << endl;
            cout << " REGROW total IS : " << total;
            cout << endl;
            valueShow(ptrArr1, total);

            cout << endl;
        }
    }
    return 0;
}
void enterValue(int *ptrArr1, int size, int &total)
{
    for (int i = 0; i < size; i++)
    {
        cout << "Enter " << i + 1 << " Value : ";
        cin >> *(ptrArr1 + i);
        total++;
    }
}
void valueShow(int *ptr, int total)
{

    for (int i = 0; i < total; i++)
    {
        cout << i + 1 << " Value : ";
        cout << *(ptr + i);
        cout << endl;
    }
}
void menu()
{
    cout << " Press 6 for Exit from program ";
    cout << endl;
    cout << " Press any key for continue The Program ";
    cout << endl;
}
void copyData(int *ptrArr1, int *temp, int total)
{
    for (int i = 0; i < total; i++)
    {
        temp[i] = ptrArr1[i];
    }
}
void insertData(int *ptr, int &total, int searchNum)
{
    *(ptr + total) = searchNum;
    total++;
}