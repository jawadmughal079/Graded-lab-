#include <iostream>
using namespace std;

void valueShow(int *ptr, int size);
int searchingFuction(int num, int size, int *ptr);
void valueShiffter(int *ptrArr1, int size, int returnSaver);
void enterValue(int *ptrArr1, int size, int &total);
void menu();
void copyData(int *ptrArr1, int *temp, int total);
void insertData(int *ptr, int &total, int searchNum);
int main()
{
    int select = 0;
    int choice = 0;
    int size = 0;
    int searchNum = 0;
    int returnSaver = 0;
    cout << " Enter a size of Array";
    cout << endl;
    cin >> size;
    int total = 0;

    int *ptrArr1 = new int[size];
    cout << "\n Enter The Value \n";
    enterValue(ptrArr1, size, total);
    cout << " \nThose Values You Entered \n";
    valueShow(ptrArr1, size);

    while (select != -1)
    {
        cout << " SELCT 1 FOR SHRINK ";
        cout << endl;
        cout << " SELCT 2 FOR REGROW ";
        cout << endl;
        cout << " SELCT -1 FOR EXIT ";
        cout << endl;
        cin >> select;
        if (select == 1)
        {
            cout
                << "\n------------------------------NOW SHRINK PROCESS IS START--------------------------------\n";
            cout << endl;

            menu();
            cout << " Choice : ";
            cin >> choice;
            if (choice == -1)
            {
                cout << "\n YOUR SHRINK PROCESS IS OVER \n";
                cout << endl;
            }
            else
            {
                cout << endl;
                cout << " Enter a num You Want To search  : ";
                cin >> searchNum;

                returnSaver = searchingFuction(searchNum, size, ptrArr1);
                cout << endl;
                if (returnSaver == -1)
                {
                    cout << " Your Value Is Not Present \n";
                    cout << endl;
                }
                else
                {
                    valueShiffter(ptrArr1, size, returnSaver);
                    size -= 1;
                    cout << " Succesfully Your Number Is Deleted ";
                    cout << endl;
                    cout << " Now Your size is " << size;
                    total--;
                    cout << endl;
                    cout << " \nThose Values are Left\n";
                    valueShow(ptrArr1, size);
                }
                cout << endl;
                if (size == 0)
                {
                    cout << "\n YOUR SHRINK PROCESS IS OVER BECAUSE SIZE IS EQUAL TO ZERO\nSOO ADD THE VALUES FIRST";
                    cout << endl;
                    break;
                }
            }
        }

        else if (select == 2)
        {
            cout
                << "\n------------------------------NOW REGROW PROCESS IS START--------------------------------\n";
            cout << endl;

            menu();
            cout << " Choice : ";
            cin >> choice;
            if (choice == -1)
            {
                cout << "\n YOUR REGROW PROCESS IS OVER \n";
                cout << endl;
            }
            else
            {
                cout << endl;
                cout << " Enter a num You Want To Add  : ";
                cin >> searchNum;

                if (total < size)
                {
                    insertData(ptrArr1, total, searchNum);
                }

                if (total >= size)
                {
                    size = size * 2;
                    int *temp = new int[size];
                    copyData(ptrArr1, temp, total);
                    delete[] ptrArr1;
                    ptrArr1 = temp;
                    insertData(ptrArr1, total, searchNum);
                }
                cout << endl;
                cout << " REGROW SIZE IS : " << size;
                cout << endl;
                cout << " REGROW total IS : " << total;
                cout << endl;
                valueShow(ptrArr1, total);

                cout << endl;
            }
        }
    }
    delete[] ptrArr1;

    return 0;
}

int searchingFuction(int num, int size, int *ptr)
{
    for (int i = 0; i < size; i++)
    {
        if (num == *(ptr + i))
        {
            return i;
            break;
        }
    }
    return -1;
}

void valueShiffter(int *ptrArr1, int size, int returnSaver)
{

    for (int i = returnSaver; i <= size; i++)
    {
        *(ptrArr1 + i) = *(ptrArr1 + i + 1);
    }
}
void enterValue(int *ptrArr1, int size, int &total)
{
    for (int i = 0; i < size; i++)
    {
        cout << "Enter " << i + 1 << " Value : ";
        cin >> *(ptrArr1 + i);
        total++;
    }
}
void valueShow(int *ptr, int total)
{

    for (int i = 0; i < total; i++)
    {
        cout << i + 1 << " Value : ";
        cout << *(ptr + i);
        cout << endl;
    }
}
void menu()
{
    cout << " Press -1 for Exit from program ";
    cout << endl;
    cout << " Press any key for continue The Program ";
    cout << endl;
}
void copyData(int *ptrArr1, int *temp, int total)
{
    for (int i = 0; i < total; i++)
    {
        temp[i] = ptrArr1[i];
    }
}
void insertData(int *ptr, int &total, int searchNum)
{
    *(ptr + total) = searchNum;
    total++;
}